# Ext.ux.Usersnap
An Extension for the Usersnap widget. Obtain a key (42 days free trial) on http://usersnap.com/signup

Usersnap is the #1 screenshot tool for web development. Get annotated screenshots of the current browser content, 
directly delivered to your bug tracker or project management tool.
