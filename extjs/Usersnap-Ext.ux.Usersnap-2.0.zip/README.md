# Ext.ux.Usersnap
Version: 2.0
An Extension for the Usersnap widget. Obtain a key (15 days free trial) on http://usersnap.com/signup

Usersnap is the #1 screenshot tool for web development. Get annotated screenshots of the current browser content, 
directly delivered to your bug tracker or project management tool.

== Changelog ==

= 2.0 =
* Updated the new Usersnap widget. More tools and features. Read the documentation on Usersnap.

= 1.0 =
* First version of this extension